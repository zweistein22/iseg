#  -*- coding: utf-8 -*-
# *****************************************************************************
# MLZ library of Tango servers
# Copyright (c) 2015-2020 by the authors, see LICENSE
#
# This program is free software; you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation; either version 2 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
# details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# Module authors:
#   Jens Krüger <jens.krueger@frm2.tum.de>
#   Georg Brandl <g.brandl@fz-juelich.de>
#
# *****************************************************************************

"""ISEQ NHQ/EHQ high-voltage power supply support."""

import time

from entangle import base
from entangle.core import ALARM, BUSY, FAULT, ON, Prop, intrange, subdev
from entangle.core.errors import CommunicationFailure, ConfigurationError, \
    InvalidOperation, InvalidValue, UnrecognizedHardware


class PowerSupply(base.PowerSupply):
    """Controls an Iseg NHQ/EHQ high-voltage power supply via string I/O."""

    properties = {
        'iodev':   Prop(subdev, 'I/O device name.'),
        'channel': Prop(intrange(1, 2), 'Channel of the HV supply.'),
    }

    iodev_defaults = {
        'class': 'StringIO',
        'baudrate': 9600,
        'eol': '\r\n',
        'echo': True,
    }

    states = {'ON':  (ON,    'on'),
              'OFF': (ALARM, 'switched off'),
              'MAN': (ALARM, 'switched to manual control'),
              'ERR': (FAULT, 'maximum voltage or current exceeded'),
              'INH': (ALARM, 'inhibit signal active'),
              'QUA': (ALARM, 'quality of voltage not guaranteed'),
              'L2H': (BUSY,  'ramping up'),
              'H2L': (BUSY,  'ramping down'),
              'LAS': (BUSY,  'look at status (?)'),
              'TRP': (FAULT, 'current trip reached')}

    def _communicate(self, cmd, args='', number=False):
        reply = self._iodev.Communicate(cmd + str(self.channel) + args)
        if reply.startswith('?'):
            raise InvalidOperation('failed: %r' % reply)
        if number:
            if reply.find('+') > 0:
                return float(reply.replace('+', 'e+'))
            elif reply.find('-') > 0:
                return float(reply.replace('-', 'e-'))
            return float(reply)
        return reply

    def init(self):
        if self.mode == 'current':
            raise ConfigurationError('Iseg HV device can only be operated in '
                                     '"voltage" mode')
        self._iodev = self.connect_client('iodev', self.iodev, 'StringIO')
        try:
            idn = self._iodev.Communicate('#')
        except CommunicationFailure:
            # May be the device wasn't in use before and the comm. timeout is
            # the # factory default, then the delay time has to be written
            # first in char by char with sleeping time between each character
            for c in 'W=001' + self._iodev.endOfLine:
                self._iodev.Write(c)
                time.sleep(0.255)
            idn = self._iodev.Communicate('#')
        idn_parts = idn.split(';')
        if len(idn_parts) != 4:
            raise UnrecognizedHardware('unrecognized response to "#": %r' %
                                       idn)
        self.hw_version = idn_parts[1]

        # set write delay to minimum (1ms)
        self._iodev.Communicate('W=001')

        # retrieve polarity
        reply = self._communicate('T')
        # 0 = negative, 1 = positive
        self._polarity = -1 + 2 * bool(int(reply) & 4)

        # retrieve maximum current
        self._currentfactor = 1.
        if idn_parts[3].endswith('uA'):
            self._currentfactor = 1000000.
        elif idn_parts[3].endswith('mA'):
            self._currentfactor = 1000.
        max_current = int(idn_parts[3].strip('umA')) / self._currentfactor
        cur_limit = self._communicate('N', number=True)
        max_current = cur_limit * max_current / 100.

        # retrieve maximum voltage
        max_voltage = int(idn_parts[2].strip('V'))
        volt_limit = self._communicate('M', number=True)
        max_voltage = volt_limit * max_voltage / 100.

        # don't set a current trip if not requested (maxcurrent is
        # overwritten by check_current_voltage_limits if == 0)
        want_trip = self.maxcurrent != 0

        # check configured limits against hardware limits
        self.check_current_voltage_limits(max_current, max_voltage,
                                          polarities=(self._polarity,))

        # set current trip
        self.write_current(self.maxcurrent if want_trip else 0)

    def state(self):
        reply = self._communicate('S')
        if reply[:3] != 'S%d=' % self.channel:
            raise CommunicationFailure('invalid status readout: %r' % reply)
        state = reply[3:].rstrip()
        st = self.states[state]
        if state in ('ERR', 'INH', 'QUA', 'LAS', 'TRP'):
            self.log.warning('device state: %s', st[1])
        return st

    def read_current(self):
        return self._communicate('I', number=True)

    def read_voltage(self):
        return self._communicate('U', number=True)

    def write_current(self, value):
        reply = self._communicate('L', '=%04d' %
                                  int(value * self._currentfactor))
        if reply:
            raise InvalidValue('could not write current value: %r' % reply)

    def write_voltage(self, value):
        voltage = abs(value)
        reply = self._communicate('D', '=%04d' % voltage)
        if reply:
            raise CommunicationFailure('could not set voltage: %r' % reply)
        reply = self._communicate('G')
        if reply[:3] != 'S%d=' % self.channel:
            raise CommunicationFailure('invalid status readout: %r' % reply)
        state = reply[3:].rstrip()
        if state not in ('H2L', 'L2H', 'ON'):
            if state == 'MAN':
                raise InvalidOperation('could not start voltage change, '
                                       'voltage control switched to manual')
            elif state == 'OFF':
                raise InvalidOperation('could not start voltage change, '
                                       'device switched off')
            else:
                raise InvalidOperation('could not start voltage change: ' +
                                       self.states[state][1])

    def write_both(self, current, voltage):
        # do not set new current trip every time
        self.write_voltage(voltage)

    def read_speed(self):
        # returns volts/second
        return self._communicate('V', number=True)

    def write_speed(self, value):
        # only write (and store) new ramp if it is different from the current
        ramp = int(value)
        cur_ramp = int(self.read_speed())
        if ramp == cur_ramp:
            return
        # sanity-check new value
        if ramp == 0:
            raise InvalidValue('ramp is too small; must be at least 60 V/min')
        elif ramp > 255:
            raise InvalidValue('ramp is too large; must be at most 15300 '
                               'V/min')
        # write ramp to device
        reply = self._communicate('V', '=%03d' % ramp)
        if reply:
            raise InvalidOperation('could not write ramp: %r' % reply)
        # save new ramp in EEPROM
        reply = self._communicate('A', '=01')
        if reply:
            raise InvalidOperation('could not save ramp: %r' % reply)
        self.log.info('ramp set to %d V/min and stored in EEPROM', ramp * 60)

    def Stop(self):
        reply = self._communicate('S')
        if reply[:3] != 'S%d=' % self.channel:
            raise CommunicationFailure('invalid status readout: %r' % reply)
        if reply[3:].rstrip() in ('OFF', 'MAN', 'ON', 'ERR', 'INH', 'TRP'):
            return
        voltage = self.read_rawValue()
        if voltage < 0 and voltage < self.absmin:
            voltage = self.absmin
        elif voltage > 0 and voltage > self.absmax:
            voltage = self.absmax
        self.write_rawValue(voltage)
