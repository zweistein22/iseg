# isegCCx
control iseq HV supply CC 2x series
